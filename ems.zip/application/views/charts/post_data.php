<!-- SENDING PHP DATA TO JAVASCRIPT -->
<script type="text/javascript">
      var baseurl = "<?php echo base_url(); ?>";
      var admin_pin = "<?php echo $this->session->userdata('pin') ?>";
</script>